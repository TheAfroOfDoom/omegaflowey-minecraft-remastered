tag @s remove omegaflowey.player.fighting_flowey

function omegaflowey:main/summit-2026/room/ruins/active_player_display/update_value with storage omegaflowey:bossfight

function omegaflowey:utils/log/self { text_component: [ \
  { "text": "Unset you as the active bossfight player", "color": "yellow" } \
] }
